package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Demo22DetailMain2Activity extends AppCompatActivity {
    TextView tv2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo22_detail_main2);
        tv2 = findViewById(R.id.demo22_Detail_Tv2);
        //Do hang
        Intent intent1 = getIntent();//đón xe chở hàng
        //bóc tách dữ liệu
        String so1 = intent1.getExtras().getString("so1");//bóc gói số 1
        String so2 = intent1.getExtras().getString("so2");//bóc gói số 2
        //chuyển sang số
        double a = Double.parseDouble(so1);
        double b = Double.parseDouble(so2);
        //tinh tong
        double c = a + b;
        //dán kết quả lên màn hình
        tv2.setText(String.valueOf(c));
    }
}
