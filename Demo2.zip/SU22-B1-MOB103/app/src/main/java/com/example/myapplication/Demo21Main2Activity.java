package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class Demo21Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo21_main2);
    }

    @Override
    protected void onStart() {
        Log.d("onStart","onStart duoc goi");
        super.onStart();
    }

    @Override
    protected void onPause() {
        Log.d("onPause","onPause duoc goi");
        super.onPause();
    }

    @Override
    protected void onResume() {
        Log.d("onResume","onResume duoc goi");
        super.onResume();
    }

    @Override
    protected void onStop() {
        Log.d("onStop","onStop duoc goi");
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        Log.d("onDestroy","onDestroy duoc goi");
        super.onDestroy();
    }

    @Override
    protected void onRestart() {
        Log.d("onRestart","onRestart duoc goi");
        super.onRestart();
    }
}
