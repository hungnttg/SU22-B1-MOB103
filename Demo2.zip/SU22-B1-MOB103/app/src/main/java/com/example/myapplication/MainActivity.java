package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView tv;//khai bao
    EditText edt12;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //anh xa
        tv = findViewById(R.id.textView12);
        edt12 = findViewById(R.id.editText12);
        //thay doi text
        tv.setText("Text da thay doi");
        edt12.setText("Thay doi lan nua");
        //Khai báo biến
        String masv = "PH0001";
        String tenSV  = "Tran Van B";
        String lop = "CP17306";
        String hienThi = masv+ "; "+tenSV+"; "+lop;
        //Hàm thông báo
        Toast.makeText(this,hienThi,Toast.LENGTH_LONG).show();

    }
}
