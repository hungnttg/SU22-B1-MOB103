package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Demo22Main2Activity extends AppCompatActivity {
    //1. Khai bao bien
    EditText txt1,txt2;
    Button btn1,btn2;
    TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo22_main2);
        //2. Anh xa
        txt1 = findViewById(R.id.demo22TxtSo1);
        txt2 = findViewById(R.id.demo22TxtSo2);
        btn1 = findViewById(R.id.demo22Btn1);
        tv1 = findViewById(R.id.demo22LblKQ);
        btn2 = findViewById(R.id.demo22Btn2);
        //3. Xu ly su kien voi button
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tinhTong();
            }
        });
        //4. Xu ly su kien voi button 2
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Su dung intent
                //1. Tao intent
                Intent intent = new Intent(Demo22Main2Activity.this,
                        Demo22DetailMain2Activity.class);
                //2. Dua du lieu vao intent
                intent.putExtra("so1",txt1.getText().toString());
                intent.putExtra("so2",txt2.getText().toString());
                //3. Chuyen du lieu di
                startActivity(intent);
            }
        });
    }
    public void tinhTong()
    {
        //Lay du lieu nguoi dung nhap vao text1
        String so1 = txt1.getText().toString();
        //Chuyen du lieu sang dang so thuc
        double a = Double.parseDouble(so1);
        //--
        //Lay du lieu nguoi dung nhap vao text2
        String so2 = txt2.getText().toString();
        //Chuyen du lieu sang dang so thuc
        double b = Double.parseDouble(so2);
        //--
        double c = a+b; //tinh tong
        //dan ket qua len man hinh
        tv1.setText("Tong la: "+String.valueOf(c));
    }
}
