package com.example.myapplication.demo7;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.myapplication.R;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Demo71Main2Activity extends AppCompatActivity {
    EditText txt1;
    Button btnGhi,btnDoc;
    TextView tv1;
    Context context  =this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo71_main2);
        txt1 = findViewById(R.id.demo71Txt1);
        tv1 = findViewById(R.id.demot71Tv1);
        btnDoc  =findViewById(R.id.demo71BtnDoc);
        btnGhi = findViewById(R.id.demo71BtnGhi);
        requestPermission();//xin quyen
        btnGhi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String kq=ghiFile(txt1.getText().toString());
                tv1.setText(kq);
            }
        });
        btnDoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String kq = docFile();
                tv1.setText(kq);
            }
        });
    }
    String ghiFile(String duLieu)
    {
        String kq="";
        String path = Environment.getExternalStorageDirectory().getAbsolutePath()
                +"/a.txt";
        try {
            OutputStreamWriter o = new OutputStreamWriter(new FileOutputStream(path));
            o.write(duLieu);
            o.close();
            kq = "Ghi thanh cong";
        } catch (FileNotFoundException e) {
            kq = "Ghi that bai";
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
            kq = "Ghi that bai";
        }
        return kq;
    }
    String docFile()
    {
        String kq="";
        String path = Environment.getExternalStorageDirectory().getAbsolutePath()
                +"/a.txt";
        try {
            Scanner s = new Scanner(new File(path));
            while (s.hasNext())
            {
                kq+=s.nextLine()+"\n";
            }
            s.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return kq;
    }
    public boolean requestPermission()
    {
        if(Build.VERSION.SDK_INT>=23)
        {
            if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    ==PackageManager.PERMISSION_GRANTED
                   )
            {
                return  true;
            }
            else
            {
                ActivityCompat.requestPermissions(Demo71Main2Activity.this,new String[]{
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                },1);
                return false;
            }
        }
        else
        {
            return true;
        }
    }
}
