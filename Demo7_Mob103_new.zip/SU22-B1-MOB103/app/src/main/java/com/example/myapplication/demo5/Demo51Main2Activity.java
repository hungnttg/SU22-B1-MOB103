package com.example.myapplication.demo5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ListView;

import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class Demo51Main2Activity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo51_main2);
        listView = findViewById(R.id.demo51Lv);
        //Nguon du lieu
        List<Product> list = new ArrayList<>();//tao danh sach trong
        list.add(new Product("10","SP10",110,R.drawable.ic_launcher_background));
        list.add(new Product("11","SP11",111,R.drawable.ic_launcher_background));
        list.add(new Product("12","SP12",112,R.drawable.ic_launcher_background));
        list.add(new Product("13","SP13",113,R.drawable.ic_launcher_background));
        list.add(new Product("14","SP14",114,R.drawable.ic_launcher_background));
        //Gọi hàm tạo database SQLite
        SQLiteHelper sqLiteHelper = new SQLiteHelper(this);//taoj database
        SQLiteDatabase database = sqLiteHelper.getWritableDatabase();//cho phep ghi
        //Insert dữ liệu vào csdl
        ContentValues values = new ContentValues();//tạo đối tượng chứa dữ liệu
        //đưa dữ liệu vào values
        values.put("id","10");
        values.put("name","SP10");
        values.put("price",100);
        values.put("image", Color.RED);
        //thực thi insert
        database.insert("PRODUCT",null,values);
        //Tạo adapter
        Demo51Adapter adapter = new Demo51Adapter(this,R.layout.item_row_51,list);
        listView.setAdapter(adapter);
    }
}
