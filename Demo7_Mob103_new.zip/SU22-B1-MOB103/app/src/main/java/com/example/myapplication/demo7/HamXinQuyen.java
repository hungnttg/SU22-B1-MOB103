package com.example.myapplication.demo7;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.ActivityCompat;

import com.example.myapplication.demo3.Demo31Main2Activity;

public class HamXinQuyen {
    Context context;

}
