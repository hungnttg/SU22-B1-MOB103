package com.example.myapplication.demo4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.myapplication.R;

import java.util.List;

public class CustomAdapter extends ArrayAdapter<Contact> {
    private Context context;
    private int resource;
    private List<Contact> objects;
    private LayoutInflater inflater;//đối tượng tạo layout
    public CustomAdapter(Context context, int resource, List<Contact> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.objects = objects;
        //khởi tạo layout chưa có các đối tượng
        this.inflater
                =(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    //Hàm gắn các đối tương + dữ liệu vào layout
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //1.Gán đối tượng vào layout
        MyViewHolder holder = new MyViewHolder();//tạo đối tượng layout liên kết với XML
        if(convertView==null)//nếu chưa ánh xạ -> thì cần ánh xa
        {
            convertView = inflater.inflate(R.layout.item_row,null);//ánh xạ layout
            //ánh xạ các thành phần con của layout
            holder.tvColor = (TextView)convertView.findViewById(R.id.demo43ItemTv1);
            holder.tvName=(TextView)convertView.findViewById(R.id.demo43ItemTv2);
            holder.tvPhone=(TextView)convertView.findViewById(R.id.demo43ItemTv3);
            //tạo template để lần sau sử dụng
            convertView.setTag(holder);
        }
        else//nếu đã ánh xạ thì ta chỉ cần lấy view về
        {
            holder = (MyViewHolder)convertView.getTag();
        }
        //2. gán dữ liệu vào layout
        Contact contact = objects.get(position);//lấy đối tượng từ danh sách truyền
        holder.tvColor.setBackgroundColor(contact.getColor());
        holder.tvName.setText(contact.getName());
        holder.tvPhone.setText(contact.getPhone());
        return convertView;
    }
    //lop anh xa voi layout XML
    public class MyViewHolder{
        TextView tvColor, tvName, tvPhone;
    }
}
