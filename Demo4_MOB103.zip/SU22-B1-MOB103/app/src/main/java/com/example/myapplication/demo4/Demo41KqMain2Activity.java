package com.example.myapplication.demo4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.myapplication.R;

public class Demo41KqMain2Activity extends AppCompatActivity {
    TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo41_kq_main2);
        tv1 = findViewById(R.id.demo41KqTv1);
        //Don intent
        Intent intent = getIntent();
        //do hang
        Bundle bundle = intent.getBundleExtra("bun");
        int a = bundle.getInt("a");
        int b = bundle.getInt("b");
        int us = uscln(a,b);
        int bs = bscnn(a,b);
        String kq = "USCLN: "+us+"; BSCNN: "+bs;
        tv1.setText(String.valueOf(kq));
    }
    int uscln(int a,int b)
    {
        if(b==0) return a;
        return uscln(b,a%b);
    }
    int bscnn(int a,int b)
    {
        return (a*b)/uscln(a,b);
    }
}
