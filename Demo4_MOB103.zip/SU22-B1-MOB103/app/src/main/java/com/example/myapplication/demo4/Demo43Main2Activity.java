package com.example.myapplication.demo4;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class Demo43Main2Activity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo43_main2);
        listView = findViewById(R.id.demo43Lv);
        //Tạo nguồn dữ liệu cho listview
        List<Contact> arrs = new ArrayList<>();
        arrs.add(new Contact(Color.RED,"Nguyen Van An","0912345678"));
        arrs.add(new Contact(Color.BLUE,"Trab Van ben","0912345699"));
        arrs.add(new Contact(Color.GREEN,"Vu Van Cong","22222345678"));
        arrs.add(new Contact(Color.YELLOW,"Nguyen Van Dung","5555345678"));
        arrs.add(new Contact(Color.RED,"Nguyen Van Dat","8888345678"));
        //goi adapter
        final CustomAdapter adapter=new CustomAdapter(this,
                R.layout.item_row,arrs);
        listView.setAdapter(adapter);
        //xu ky su kien khi click adapter
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Contact contact = arrs.get(i);
                Toast.makeText(getApplicationContext(),contact.getName(),Toast.LENGTH_LONG).show();
            }
        });
    }
}
