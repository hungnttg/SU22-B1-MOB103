package com.example.myapplication.demo6;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.myapplication.demo5.SQLiteHelper;

import java.util.ArrayList;
import java.util.List;

public class SanPhamDAO {
    private Context context;
    private SQLiteHelper dbHelper;
    private SQLiteDatabase db;
    //Khởi tạo
    public SanPhamDAO(Context context) {
        this.context = context;
        dbHelper = new SQLiteHelper(context);//thực thi tạo CSDL và bảng dữ liệu
        db = dbHelper.getWritableDatabase();//cho phép ghi dữ liệu vào bảng dữ liệu
    }
    //1. Thêm dữ liệu
    public int insertSanPham(SanPham s)
    {
        //1.1. Taọ đối tượng chứa dữ liệu
        ContentValues values = new ContentValues();
        //1.2 Đưa dữ liệu vào đối tượng chứa
        values.put("masp",s.getMasp());
        values.put("tensp",s.getTensp());
        values.put("soluongSP",s.getSoluongSP());
        //1.3 Thực thi insert
        //insert(tenBang,dieuKien,GiaTriCanThem)
        long kq = db.insert("sanpham",null,values);
        //1.4. Kiểm tra kết quả
        if(kq<=0)
        {
            return -1;
        }
        return 1;
    }
    //2. đọc dữ liệu lên listview (hiển thị)
    //chức năng: đọc dữ liệu trong bảng và chuyển toàn bộ sang chuỗi
    public List<String> getAllSanPhamToString()
    {
        //2.1. Tạo 1 danh sách rỗng
        List<String> list = new ArrayList<>();
        //2.2. tạo con trỏ đọc dữ liệu
        Cursor c = db.query("sanpham",null,null,null,
                null,null,null);
        //2.3. Di chuyển con trỏ về bản ghi đầu tiên
        c.moveToFirst();
        //2.4 đọc dữ liệu qua vòng lặp while
        while (c.isAfterLast()==false)//nếu không phải bản ghi cuối cùng thì tiếp tục đọc
        {
            //2.4.1. Tạo đối tượng chứa dữ liệu đọc được
            SanPham s = new SanPham();
            //2.4.2. Đưa từng trường dữ liệu đọc được vào đối tượng
            s.setMasp(c.getString(0));//đọc trường masp
            s.setTensp(c.getString(1));//đọc trường tensp
            s.setSoluongSP(c.getInt(2));//đọc trường số lượng
            //2.4.3 Chuyển tất cả sang chuỗi
            String chuoi = s.getMasp()+" - "+s.getTensp()+" - "+s.getSoluongSP();
            //2.4.5 - đưa vào list
            list.add(chuoi);
            //2.4.6. di chuyển sang bản ghi tiếp theo
            c.moveToNext();
        }
        //2.5 đóng con trỏ
        c.close();
        return list;
    }
    //3. Xoa
    public int deleteSanPham(String masp)
    {
        //delete(tenBang,dieuKien,ThamSoTruyen)
        int kq = db.delete("sanpham","masp=?",
                new String[]{masp});
        //kiem tra ket qua
        if(kq<=0)
        {
            return -1;
        }
        return 1;
    }
    //4. sua
    public int updateSanPham(SanPham s)
    {
        //1.1. Taọ đối tượng chứa dữ liệu
        ContentValues values = new ContentValues();
        //1.2 Đưa dữ liệu vào đối tượng chứa
        values.put("masp",s.getMasp());
        values.put("tensp",s.getTensp());
        values.put("soluongSP",s.getSoluongSP());
        //1.3 Thực thi update
        //update(tenBang,GiaTriCanSua,DieuKien,ThamSoTruyen)
        long kq = db.update("sanpham",values,"masp=?",
                new String[]{s.getMasp()});
        //1.4. Kiểm tra kết quả
        if(kq<=0)
        {
            return -1;
        }
        return 1;
    }
}
