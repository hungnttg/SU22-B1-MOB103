package com.example.myapplication.demo7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.myapplication.R;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Demo71Main2Activity extends AppCompatActivity {
    Button btnGhi,btnDoc;
    EditText txt1;
    TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo71_main2);
        txt1 = findViewById(R.id.demo71Txt1);
        tv1 = findViewById(R.id.demo71Tv1);
        btnDoc = findViewById(R.id.demo71BtnDoc);
        btnGhi = findViewById(R.id.demo71BtnGhi);
        btnGhi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ghiDuLieu(txt1.getText().toString());
            }
        });
        btnDoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s = docDulieu();
                tv1.setText(s);
            }
        });
    }
    public void ghiDuLieu(String dulieu)
    {
        //B1- lay duong dan
        String path = Environment.getExternalStorageDirectory().getAbsolutePath()
                +"/data1.txt";
        //b2- Thuc hien tao luong ghi
        try {
            OutputStreamWriter o
                    = new OutputStreamWriter(new FileOutputStream(path));
            //b3- ghi
            o.write(dulieu);
            //b4- dong luong
            o.close();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public String docDulieu()
    {
        String dulieu="";
        //B1- lay duong dan
        String path = Environment.getExternalStorageDirectory().getAbsolutePath()
                +"/data1.txt";
        try {
            Scanner s = new Scanner(new File(path));
            while (s.hasNext())
            {
                dulieu = s.nextLine()+"\n";
            }
            s.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dulieu;
    }
}
