package com.example.myapplication.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication.R;

public class Demo31Main2Activity extends AppCompatActivity {
    //1. Khai báo
    EditText txt1,txt2;
    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo31_main2);
        //2. Ánh xạ
        txt1 = findViewById(R.id.demo31Txt1);
        txt2 = findViewById(R.id.demo31Txt2);
        btn1  =findViewById(R.id.demo31Btn1);
        //3. Xử lý sự kiện
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dangnhap();
            }
        });
    }
    public void dangnhap()
    {
        String u = txt1.getText().toString();//lấy dữ liệu nhập vào từ ô 1
        String p = txt2.getText().toString();//lấy dữ liệu nhập vào từ ô 2
        if(u.equals("admin")&&p.equals("admin"))
        {
            Toast.makeText(getApplicationContext(),"Đăng nhập thành công",Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(getApplicationContext(),"Đăng nhập thất bại",Toast.LENGTH_LONG).show();
        }
    }

}
