package com.example.myapplication.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.myapplication.R;

public class Demo33Main2Activity extends AppCompatActivity {
    //1. Khai bao
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo33_main2);
        //2. Anh xa
        listView = findViewById(R.id.demo33Listview);
        layDuLieuDuaLenListview();
    }
    public void layDuLieuDuaLenListview()
    {
        //B1 - Tạo mảng nguồn dữ liệu
        String[] ar = new String[]
                {
                        "Lap trinh java 1",
                        "Lap trinh Java2",
                        "Lap trinh android co ban",
                        "HTML5 va CSS3",
                        "Xay dung trang web",
                        "Lap trinh C"
                };
        //B2 - Truyền dữ liệu vào Adapter
        ArrayAdapter<String> adapter
                =new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,ar);
        //B3 - Đưa lên listview
        listView.setAdapter(adapter);
    }
}
