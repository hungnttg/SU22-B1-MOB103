package com.example.myapplication.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.myapplication.R;

public class Demo32Main2Activity extends AppCompatActivity {
    //1.Khai bao
    EditText txtA,txtB,txtC;
    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo32_main2);
        //2. Anh xa
        txtA = findViewById(R.id.demo32Txt1);
        txtB = findViewById(R.id.demo32Txt2);
        txtC = findViewById(R.id.demo32Txt3);
        btn1 = findViewById(R.id.demo32Btn1);
        //b3. Xu ly su kien
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //3.1. Lay du lieu
                String strA = txtA.getText().toString();//lay du lieu nhap vao A
                String strB = txtB.getText().toString();//lay du lieu nhap vao B
                String strC = txtC.getText().toString();//lay du lieu nhap vao C
                //3.2. Intent chuyen du lieu
                Intent intent = new Intent(Demo32Main2Activity.this,
                        Demo32KQMain2Activity.class);
                //3.3. Dua du lieu vao intent
                intent.putExtra("a",strA);
                intent.putExtra("b",strB);
                intent.putExtra("c",strC);
                //3.4 CHuyen du lieu sang Activity moi
                startActivity(intent);
            }
        });
    }
}
