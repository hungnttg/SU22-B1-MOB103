package com.example.myapplication.demo4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.myapplication.R;

import java.util.List;

public class CustomAdapter extends ArrayAdapter<Contact> {
    private Context context;
    private int resource;
    private List<Contact> objects;
    private LayoutInflater inflater;//biến vẽ layout
    public CustomAdapter(Context context, int resource, List<Contact> objects) {
        super(context, resource, objects);
        this.context = context;
        this.objects = objects;
        this.resource = resource;
        //khởi tạo vẽ layout
        this.inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //1. Taọ view
        MyViewHolder holder;
        if(convertView==null)//nếu chưa có view -> thì tạo mới
        {
            convertView = inflater.inflate(R.layout.item_row,null);//taọ khung layout
            //gán đối tượng cho layout
            holder = new MyViewHolder();
            holder.tvColor = convertView.findViewById(R.id.demo43ItemTv1);//ánh xạ
            holder.tvName = convertView.findViewById(R.id.demo43ItemTv2);//ánh xạ
            holder.tvPhone = convertView.findViewById(R.id.demo43ItemTv3);//ánh xạ
            //tạo template để lần sau sử dụng
            convertView.setTag(holder);
        }
        else //nếu có view rồi => lấy ra sử dụng
        {
            holder = (MyViewHolder)convertView.getTag();
        }
        //2. Gán dữ liệu
        Contact c = objects.get(position);
        holder.tvColor.setBackgroundColor(c.getColor());
        holder.tvName.setText(c.getName());
        holder.tvPhone.setText(c.getPhone());
        return convertView;
    }

    //Tạo lớp ánh xạ với layout
    public class MyViewHolder{
        TextView tvColor, tvName, tvPhone;
    }
}
