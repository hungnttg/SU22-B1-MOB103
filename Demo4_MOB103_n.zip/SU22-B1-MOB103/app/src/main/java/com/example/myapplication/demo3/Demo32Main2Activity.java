package com.example.myapplication.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.myapplication.R;

public class Demo32Main2Activity extends AppCompatActivity {
    //1. khai bao
    EditText txtA,txtB,txtC;
    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo32_main2);
        //2. Anh xa
        txtA = findViewById(R.id.demo32Txt1);
        txtB = findViewById(R.id.demo32Txt2);
        txtC = findViewById(R.id.demo32Txt3);
        btn1 = findViewById(R.id.demo32Btn1);
        //3. Xu ly su kien
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //B1. Lay du lieu nhap cua nguoi dung
                double a = Double.parseDouble(txtA.getText().toString());//lay he so a
                double b = Double.parseDouble(txtB.getText().toString());//lay he so b
                double c = Double.parseDouble(txtC.getText().toString());//lay he so c
                //B2. tao intent
                Intent intent = new Intent(Demo32Main2Activity.this,
                        Demo32KqMain2Activity.class);
                //B3. dua du lieu vao intent
                intent.putExtra("a",a);
                intent.putExtra("b",b);
                intent.putExtra("c",c);
                //b4 - Chuyen du lieu di
                startActivity(intent);
            }
        });
    }
}
