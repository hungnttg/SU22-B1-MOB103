package com.example.myapplication.demo4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.myapplication.R;

public class Demo41Main2Activity extends AppCompatActivity {
    EditText txt1,txt2;
    Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo41_main2);
        txt1 = findViewById(R.id.demo41txt1);
        txt2 = findViewById(R.id.demo41Txt2);
        btn1 = findViewById(R.id.demo41Btn1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Demo41Main2Activity.this,
                        Demo41KqMain2Activity.class);
                //Lấy dữ liệu người dùng nhập
                int a = Integer.parseInt(txt1.getText().toString());
                int b = Integer.parseInt(txt2.getText().toString());
                //Tạo bundler chứa dữ liệu
                Bundle bundle = new Bundle();
                //đưa dữ liệu vào bundle
                bundle.putInt("a",a);
                bundle.putInt("b",b);
                //đưa bundle vào intent
                intent.putExtra("bun",bundle);
                //vận chuyển dữ liệu
                startActivity(intent);

            }
        });
    }
}
