package com.example.myapplication.demo6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.myapplication.R;
import com.example.myapplication.demo5.SanPhamDAO;

import java.util.ArrayList;
import java.util.List;

public class Demo61Main2Activity extends AppCompatActivity {
    EditText txtMa,txtTen,txtSL;
    Button btnThem, btnSua, btnXoa, btnHienThi;
    ListView listView;
    ArrayAdapter<String> arrayAdapter;
    SanPhamDAO sanPhamDAO;
    List<String> list = new ArrayList<>();//tạo list rỗng
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo61_main2);
        //anh xa
        txtMa  =findViewById(R.id.demo61Txt1);
        txtTen = findViewById(R.id.demo61Txt2);
        txtSL = findViewById(R.id.demo61Txt3);
        btnThem = findViewById(R.id.demo61BtnThem);
        btnSua = findViewById(R.id.demo61BtnSua);
        btnXoa = findViewById(R.id.demo61BtnXoa);
        btnHienThi = findViewById(R.id.demo61BtnHienThi);
        listView = findViewById(R.id.demo61Listview);
        //Khởi tạo các biến
        context = this;
        //--hien thi du lieu khi chay chuong trinh
        list.clear();//xóa hết nội dung trong list
        sanPhamDAO = new SanPhamDAO(context);//tạo csdl và bảng dữ liệu
        list = sanPhamDAO.getAllSanPhamToString();
        arrayAdapter = new ArrayAdapter<>(context,android.
                R.layout.simple_list_item_1,list);
        listView.setAdapter(arrayAdapter);
        //----button hien thi
        btnHienThi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                list.clear();//xóa hết nội dung trong list
                sanPhamDAO = new SanPhamDAO(context);//tạo csdl và bảng dữ liệu
                list = sanPhamDAO.getAllSanPhamToString();//lấy toàn bộ sanpham trong bảng sản phẩm
                arrayAdapter = new ArrayAdapter<>(context,
                        android.R.layout.simple_list_item_1,list);//tạo adapter
                listView.setAdapter(arrayAdapter);//đẩy dữ liệu vào listview
            }
        });
        //-----button them
        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SanPham s = new SanPham();//tạo đối tượng chứa dữ liệu người dùng nhập
                //đưa dữ liệu vào đối tượng
                s.setMasp(txtMa.getText().toString());
                s.setTensp(txtTen.getText().toString());
                s.setSoluongSP(Integer.parseInt(txtSL.getText().toString()));
                //gọi hàm insert
                int kq = sanPhamDAO.InsertSanPham(s);
                if(kq==-1)//kiểm tra kết quả
                {
                    Toast.makeText(context,"Insert thất bại",Toast.LENGTH_LONG).show();
                }
                if(kq==1)
                {
                    Toast.makeText(context,"Insert thành công",Toast.LENGTH_LONG).show();
                }
            }
        });
        //----xoa
        btnXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String masp = txtMa.getText().toString();
                int kq = sanPhamDAO.DeleteSanPham(masp);
                if(kq==-1)//kiểm tra kết quả
                {
                    Toast.makeText(context,"Xoa thất bại",Toast.LENGTH_LONG).show();
                }
                if(kq==1)
                {
                    Toast.makeText(context,"Xoa thành công",Toast.LENGTH_LONG).show();
                }
            }
        });
        //---
        btnSua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SanPham s = new SanPham();//tạo đối tượng chứa dữ liệu người dùng nhập
                //đưa dữ liệu vào đối tượng
                s.setMasp(txtMa.getText().toString());
                s.setTensp(txtTen.getText().toString());
                s.setSoluongSP(Integer.parseInt(txtSL.getText().toString()));
                //gọi hàm insert
                int kq = sanPhamDAO.UpdateSanPham(s);
                if(kq==-1)//kiểm tra kết quả
                {
                    Toast.makeText(context,"Update thất bại",Toast.LENGTH_LONG).show();
                }
                if(kq==1)
                {
                    Toast.makeText(context,"update thành công",Toast.LENGTH_LONG).show();
                }
            }
        });

    }
}
