package com.example.myapplication.demo5;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.myapplication.demo6.SanPham;

import java.util.ArrayList;
import java.util.List;

public class SanPhamDAO {
    private SQLiteDatabase db;
    private SQLiteHelper dbHelper;
    private Context context;

    public SanPhamDAO(Context context) {
        this.context = context;
        dbHelper = new SQLiteHelper(context);//thực thi tạo database
        db = dbHelper.getWritableDatabase();//cho phép ghi dữ liệu vào database
    }
    //1. thêm dữ liệu
    public int InsertSanPham(SanPham s)
    {
        ContentValues values = new ContentValues();//tạo đối tượng chứa dữ liệu
        //đưa dữ liệu vào đối tượng chứa
        values.put("masp",s.getMasp());
        values.put("tensp",s.getTensp());
        values.put("soluongSP",String.valueOf(s.getSoluongSP()));
        //thực thi insert
        long kq = db.insert("sanpham",null,values);
        //kiểm tra kết quả insert
        if(kq<=0)
        {
            return -1;//insert thất bại
        }
        return 1;//insert thành công
    }
    //2. hiển thị dữ liệu dạng String
    public List<String> getAllSanPhamToString()
    {
        List<String> ls = new ArrayList<>();//tạo danh sách rỗng
        //Tạo con trỏ đọc bảng dữ liệu sanpham
        Cursor c = db.query("sanpham",null,null,null,
                null,null,null);
        c.moveToFirst();//di chuyển con trỏ về bản ghi đầu tiên
        //đọc
        while (c.isAfterLast()==false)//trong khi không phải dòng cuối cùng=> vẫn đọc
        {
            SanPham s = new SanPham();//tạo đối tượng chứa dữ liệu
            s.setMasp(c.getString(0));//đọc dữ liệu trường masp và đưa vào đối tượng
            s.setTensp(c.getString(1));//đọc dữ liệu trường tensp và đưa vào đối tượng
            s.setSoluongSP(c.getInt(2));//đọc dữ liệu trường soluongSP và đưa vào đối tượng
            //CHuyển đối tượng thành chuỗi
            String chuoi = s.getMasp()+" - "+s.getTensp()+" - "+s.getSoluongSP();
            //đưa chuỗi vào list
            ls.add(chuoi);
            c.moveToNext();//di chuyển đến bản ghi tiếp theo
        }
        c.close();//đóng con trỏ
        return ls;
    }
    //xóa
    public int DeleteSanPham(String masp)
    {
        //thực thi xóa
        int kq = db.delete("sanpham","masp=?",
                new String[]{masp});
        //kiểm tra kết quả insert
        if(kq<=0)
        {
            return -1;//xoa thất bại
        }
        return 1;//xoa thành công
    }
    //sửa
    public int UpdateSanPham(SanPham s)
    {
        ContentValues values = new ContentValues();//tạo đối tượng chứa dữ liệu
        //đưa dữ liệu vào đối tượng chứa
        values.put("masp",s.getMasp());
        values.put("tensp",s.getTensp());
        values.put("soluongSP",String.valueOf(s.getSoluongSP()));
        //thực thi update
        long kq = db.update("sanpham",values,"masp=?",
                new String[]{s.getMasp()});
        //kiểm tra kết quả insert
        if(kq<=0)
        {
            return -1;//insert thất bại
        }
        return 1;//insert thành công
    }
}
