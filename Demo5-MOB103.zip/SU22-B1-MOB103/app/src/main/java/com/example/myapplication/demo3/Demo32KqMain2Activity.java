package com.example.myapplication.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.myapplication.R;

public class Demo32KqMain2Activity extends AppCompatActivity {
    TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo32_kq_main2);
        tv1 = findViewById(R.id.demo32KqTv1);
        //B4 - đón intent
        Intent intent = getIntent();
        //B5. do hang
        double a = intent.getExtras().getDouble("a");
        double b = intent.getExtras().getDouble("b");
        double c = intent.getExtras().getDouble("c");
        //Tinh toan
        double delta = b*b-4*a*c;
        if(delta<0)
        {
            tv1.setText("Phuong trinh vo nghiem");
        }
        else  if(delta==0)
        {
            double x = -b/(2*a);
            tv1.setText("Co nghiem kep x="+x);
        }
        else
        {
            double x1 = (-b+Math.sqrt(delta))/(2*a);
            double x2 = (-b-Math.sqrt(delta))/(2*a);
            tv1.setText("2 nghiem x1="+x1+"; va x2="+x2);
        }

    }
}
