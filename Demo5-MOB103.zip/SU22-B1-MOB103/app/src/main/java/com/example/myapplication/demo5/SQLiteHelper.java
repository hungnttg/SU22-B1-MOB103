package com.example.myapplication.demo5;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class SQLiteHelper extends SQLiteOpenHelper {
    public static final String DBNAME = "QLBH";
    public static final int VERSION = 1;
    public static final String CREATE_TABLE_PRODUCT="CREATE TABLE PRODUCT (" +
            "id text PRIMARY KEY," +
            "name text," +
            "price real," +
            "image real);";
    //Định nghĩa hàm tạo csdl
    public SQLiteHelper(Context context) {
        super(context, DBNAME, null, VERSION);
    }
    //Khởi tạo bảng dữ liệu
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE_PRODUCT);//thực thi tạo bảng dữ liệu
    }
    //Nâng cấp bảng dữ liệu
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS PRODUCT;");//xóa bảng cũ, tạo bảng mới
    }
}
