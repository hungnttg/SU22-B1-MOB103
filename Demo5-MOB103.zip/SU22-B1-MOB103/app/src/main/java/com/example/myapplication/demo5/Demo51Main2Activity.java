package com.example.myapplication.demo5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ListView;

import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class Demo51Main2Activity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo51_main2);
        listView = findViewById(R.id.demo51Lv);

        List<Product> list = new ArrayList<>();//tạo danh sách dữ liệu đổ vào listview
        list.add(new Product("1","SP1",111, Color.RED));
        list.add(new Product("2","SP2",222, Color.GRAY));
        list.add(new Product("3","SP3",333, Color.GREEN));
        list.add(new Product("4","SP4",444, Color.BLUE));
        list.add(new Product("5","SP5",555, Color.YELLOW));
        //Gọi hàm tạo CSDL để tạo csdl
        SQLiteHelper sqLiteHelper = new SQLiteHelper(this);
        SQLiteDatabase db = sqLiteHelper.getWritableDatabase();

        //db.insert("PRODUCT",null, values);
        //Adapter
        Demo51CustomAdapter adapter
                =new Demo51CustomAdapter(this,R.layout.item_row_51,list);
        listView.setAdapter(adapter);

    }
}
