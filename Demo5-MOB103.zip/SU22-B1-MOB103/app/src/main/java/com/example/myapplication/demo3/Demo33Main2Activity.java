package com.example.myapplication.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.myapplication.R;

public class Demo33Main2Activity extends AppCompatActivity {
    //1. khai bao
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo33_main2);
        //2. Anh xa
        listView = findViewById(R.id.demo33Listview);
        //3. goi ham
        dienDuLieuVaoListView();
    }
    void dienDuLieuVaoListView()
    {
        //b1- Nguon du lieu
        String[] arr = new String[]{
          "Lap trinh C",
          "Lap trinh Java1",
          "Co so du lieu",
          "Thiet ke trang web",
          "Lap trinh javascript",
           "android co ban",
        };
        //2. dua du lieu vao adapter
        ArrayAdapter<String>
          adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,arr);
        //3. Gan Listview voi Adapter
        listView.setAdapter(adapter);
    }
}
