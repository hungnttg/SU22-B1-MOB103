package com.example.myapplication.demo4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.myapplication.R;

public class Demo41KqMain2Activity extends AppCompatActivity {
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo41_kq_main2);
        textView = findViewById(R.id.demo41KqTv1);
        //đón intent
        Intent intent = getIntent();
        //dỡ hàng
        Bundle bundle = intent.getBundleExtra("bun");
        int a = bundle.getInt("a");
        int b = bundle.getInt("b");
        //tinhs toan
        int us = USCNL(a,b);
        int bs = BSCNN(a,b);
        textView.setText("USCLN la: "+us+"; BSCNN la: "+bs);
    }
    int USCNL(int a,int b)
    {
        if(b==0) return a;
        return USCNL(b,a%b);
    }
    int BSCNN(int a,int b)
    {
        return (a*b)/USCNL(a,b);
    }
}
