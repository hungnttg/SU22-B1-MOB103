package com.example.myapplication.demo5;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.myapplication.R;

import java.util.List;

public class Demo51CustomAdapter extends ArrayAdapter<Product> {
    private Context context;
    private List<Product> objects;
    private int resource;
    private LayoutInflater inflater;//đối tượng sinh layout
    public Demo51CustomAdapter(Context context, int resource, List<Product> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.objects = objects;
        inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    //gọi hàm getView(để tạo layout, object + gán dữ liệu)

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //1. tạo layout + gán object vào layout
        MyViewHolder holder;
        if(convertView==null)//nếu chưa có view, thì cần tạo view mới
        {
            convertView = inflater.inflate(R.layout.item_row_51,null);//tạo layout trắng
            //gán đối tượng vào layout (bằng cách ánh xạ)
            holder = new MyViewHolder();
            holder.tvImage = convertView.findViewById(R.id.demo51TvImage);
            holder.tvName = convertView.findViewById(R.id.demo51TvName);
            holder.tvPrice = convertView.findViewById(R.id.demo51TvPrice);
            //tạo template để lần sau sử dụng
            convertView.setTag(holder);
        }
        else //nếu đã có view rồi, lấy ra sử dụng
        {
            holder = (MyViewHolder)convertView.getTag();
        }
        //2. gán dữ liệu
        Product product = objects.get(position);
        holder.tvImage.setBackgroundColor(product.getImage());
        holder.tvName.setText(product.getName());
        holder.tvPrice.setText(String.valueOf(product.getPrice()));
        return convertView;
    }

    //Tạo viewHolder ánh xạ với Item_row
    class MyViewHolder{
        TextView tvImage, tvName,tvPrice;
    }
}
