package com.example.myapplication.demo5;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.myapplication.R;

import java.util.List;

public class Demo51CustomAdapter extends ArrayAdapter<Product> {
    private Context context;
    private List<Product> objects;
    private int resource;
    private LayoutInflater inflater;//đối tượng tạo layout
    public Demo51CustomAdapter(Context context, int resource, List<Product> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.objects = objects;
        //gọi dịch vụ khởi tạo layout
        this.inflater =
                (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    //gọi hàm getView
    //1. tạo layout + gán đối tượng vào layout
    //2. đổ dữ liệu vào đối tượng

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //1. tạo layout + gán đối tượng vào layout
        Demo51ViewHolder holder;
        if(convertView==null)//nếu chưa có view -> tạo view mới
        {
            //khởi tạo layout trắng
            convertView = inflater.inflate(R.layout.item_row_demo51,null);
            //ánh xạ các đối tượng trong item_row vào layout
            holder = new Demo51ViewHolder();
            holder.tvImage = convertView.findViewById(R.id.demo51ItemTv1);
            holder.tvName = convertView.findViewById(R.id.demo51ItemTv2);
            holder.tvPrice = convertView.findViewById(R.id.demo51ItemTv3);
            //tạo template để lần sau sử dụng
            convertView.setTag(holder);
        }
        else //nếu đã có view -> lấy ra sử dụng
        {
            holder = (Demo51ViewHolder)convertView.getTag();
        }
        //2. đổ dữ liệu vào đối tượng
        Product p = objects.get(position);
        holder.tvImage.setBackgroundColor(p.getImage());
        holder.tvName.setText(p.getName());
        holder.tvPrice.setText(String.valueOf(p.getPrice()));
        return convertView;
    }

    //Thiết kế lớp ánh xạ với item_row
    public class Demo51ViewHolder{
        TextView tvImage,tvName,tvPrice;
    }
}
