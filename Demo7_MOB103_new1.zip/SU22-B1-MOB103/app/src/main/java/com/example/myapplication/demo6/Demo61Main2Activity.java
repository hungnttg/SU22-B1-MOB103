package com.example.myapplication.demo6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class Demo61Main2Activity extends AppCompatActivity {
    EditText txtMa,txtTen,txtSL;
    Button btnThem,btnSua,btnXoa,btnHienThi;
    ListView listView;
    //1. Khai báo biến
    SanPhamDAO sanPhamDAO;
    ArrayAdapter<String> arrayAdapter;
    List<String> ls = new ArrayList<>();
    Context context = this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo61_main2);
        //2. Anh xa
        txtMa = findViewById(R.id.demo61Txt1);
        txtTen = findViewById(R.id.demo61Txt2);
        txtSL = findViewById(R.id.demo61Txt3);
        btnThem = findViewById(R.id.demo61BtnThem);
        btnSua = findViewById(R.id.demo61BtnSua);
        btnXoa = findViewById(R.id.demo61BtnXoa);
        btnHienThi = findViewById(R.id.demo61BtnHienThi);
        listView = findViewById(R.id.demo61Listview);
        //3. khởi tạo các biến
        sanPhamDAO = new SanPhamDAO(context);
        //---hiển thị lên listview
        ls.clear();//xóa trắng danh sách
        ls = sanPhamDAO.getAllSanPhamToString();//đọc dữ liệu từ bảng và đổ vào ls
        arrayAdapter = new ArrayAdapter<>(context,android.R.layout.simple_list_item_1,ls);
        listView.setAdapter(arrayAdapter);
        //---xử lý sự kiện button hiển thị
        btnHienThi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ls.clear();//xóa trắng danh sách
                ls = sanPhamDAO.getAllSanPhamToString();//đọc dữ liệu từ bảng và đổ vào ls
                arrayAdapter = new ArrayAdapter<>(context,android.R.layout.simple_list_item_1,ls);
                listView.setAdapter(arrayAdapter);
            }
        });
        //xử lý button thêm
        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //1. tạo đối tượng chứa dữ liệu
                SanPham s = new SanPham();
                //2. đưa dữ liệu người dùng nhập vào đối tượng
                s.setMasp(txtMa.getText().toString());
                s.setTensp(txtTen.getText().toString());
                s.setSoluongSP(Integer.parseInt(txtSL.getText().toString()));
                //3. thực thi insert
                int kq = sanPhamDAO.insertSanPham(s);
                //4. Kiểm tra kết quả
                if(kq==-1)
                {
                    Toast.makeText(context,"Insert that bai",Toast.LENGTH_LONG).show();
                }
                if(kq==1)
                {
                    Toast.makeText(context,"Insert thanh cong",Toast.LENGTH_LONG).show();
                }
            }
        });
        //xu ly button xoa
        btnXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String masp = txtMa.getText().toString();//lấy mã do người dùng nhập
                int kq = sanPhamDAO.deleteSanPham(masp);//thực thi xóa
                //4. Kiểm tra kết quả
                if(kq==-1)
                {
                    Toast.makeText(context,"Delete that bai",Toast.LENGTH_LONG).show();
                }
                if(kq==1)
                {
                    Toast.makeText(context,"Delete thanh cong",Toast.LENGTH_LONG).show();
                }
            }
        });
        //xu ly button sua
        btnSua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //1. tạo đối tượng chứa dữ liệu
                SanPham s = new SanPham();
                //2. đưa dữ liệu người dùng nhập vào đối tượng
                s.setMasp(txtMa.getText().toString());
                s.setTensp(txtTen.getText().toString());
                s.setSoluongSP(Integer.parseInt(txtSL.getText().toString()));
                //3. thực thi insert
                int kq = sanPhamDAO.updateSanPham(s);
                //4. Kiểm tra kết quả
                if(kq==-1)
                {
                    Toast.makeText(context,"Update that bai",Toast.LENGTH_LONG).show();
                }
                if(kq==1)
                {
                    Toast.makeText(context,"Update thanh cong",Toast.LENGTH_LONG).show();
                }
            }
        });

    }
}
