package com.example.myapplication.demo7;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.myapplication.R;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Demo71Main2Activity extends AppCompatActivity {
    EditText txt1;
    Button btnGhi,btnDoc;
    TextView tv1;
    Context context=this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo71_main2);
        requestPermission();
        txt1 = findViewById(R.id.demo71Txt1);
        tv1 =  findViewById(R.id.demo71Tv1);
        btnDoc = findViewById(R.id.demo71BtnDoc);
        btnGhi = findViewById(R.id.demo71BtnGhi);
        btnGhi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String kq = saveData(txt1.getText().toString());
                tv1.setText(kq);
            }
        });
        btnDoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String kq = readData();
                tv1.setText(kq);
            }
        });
    }
    String readData()
    {
       String kq = "";
        String path="";
        ContextWrapper cw = new ContextWrapper(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD_MR1) {
            path= cw.getExternalFilesDir(Environment.DIRECTORY_DCIM) + "/data1.txt";
        }
        else
        {
            path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/data1.txt";
        }
        try {
            Scanner s = new Scanner(new File(path));
            while (s.hasNext())
            {
                kq+=s.nextLine()+"\n";
            }
            s.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            kq = e.getMessage();
        }
        return kq;
    }
    String saveData(String data)
    {
        String path="";
        ContextWrapper cw = new ContextWrapper(context);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD_MR1) {
            path= cw.getExternalFilesDir(Environment.DIRECTORY_DCIM) + "/data1.txt";
        }
        else
        {
            path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/data1.txt";
        }
        try {
            OutputStreamWriter o = new OutputStreamWriter(new FileOutputStream(path,true));
            o.write(" "+data);
            o.close();
            return "Luu du lieu thanh cong";
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return e.getMessage();
        } catch (IOException e) {
            e.printStackTrace();
            return e.getMessage();
        }
    }
    public boolean requestPermission()
    {
        if(Build.VERSION.SDK_INT>=23)
        {
            if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
            == PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            == PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.MANAGE_EXTERNAL_STORAGE)
            == PackageManager.PERMISSION_GRANTED)
            {
                return true;
            }
            else //neu k duoc gan se xin quyen
            {
                ActivityCompat.requestPermissions(Demo71Main2Activity.this,new String[]{
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.MANAGE_EXTERNAL_STORAGE
                },1);
                return false;
            }
        }
        else {
            return true;
        }
    }
}
