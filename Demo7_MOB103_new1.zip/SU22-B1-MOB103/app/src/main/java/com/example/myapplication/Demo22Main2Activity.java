package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Demo22Main2Activity extends AppCompatActivity {
    //1.Khai báo biến
    EditText txt1,txt2;
    Button btn1,btn2;
    TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo22_main2);
        //2. Ánh xạ
        txt1 = findViewById(R.id.demo22Txt1);
        txt2 = findViewById(R.id.demo22Txt2);
        btn1 = findViewById(R.id.demo22Btn1);
        btn2 = findViewById(R.id.demo22Btn2);
        tv1 = findViewById(R.id.demo22Tv1);
        //3. xử lý sự kiện click button
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //b1- Tao intent
                Intent intent = new Intent(Demo22Main2Activity.this,
                        Demo23Main2Activity.class);
                //b2- Lấy dữ liệu người dùng nhập và đưa vào intent
                String so1 = txt1.getText().toString();//lấy dữ liệu nhập vào ô 1
                String so2 = txt2.getText().toString();//lấy dữ liệu nhập vào ô 2
                intent.putExtra("so1",so1);//đưa gói dữ liệu 1 vào intent
                intent.putExtra("so2",so2);//đưa gói dữ liệu 2 vào intent
                //b3 - cho intent vận chuyển dữ liêu
                startActivity(intent);
            }
        });
        //4. Xử lý button 2
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String so1 = txt1.getText().toString();//lấy dữ liệu nhập vào ô 1
                String so2 = txt2.getText().toString();//lấy dữ liệu nhập vào ô 2

                //chuyển đổi sang số
                double a = Double.parseDouble(so1);
                double b = Double.parseDouble(so2);
                //tinh tong
                double c = a+b;
                //dán lên màn hình
                tv1.setText(String.valueOf(c));
            }
        });
    }
}
