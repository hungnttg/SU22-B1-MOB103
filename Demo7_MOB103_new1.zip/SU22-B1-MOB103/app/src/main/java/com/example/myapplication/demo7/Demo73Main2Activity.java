package com.example.myapplication.demo7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class Demo73Main2Activity extends AppCompatActivity {
    EditText txtU,txtP;
    Button btnLogin,btnCancel;
    CheckBox chk;
    TextView tvkq;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo73_main2);
        txtP = findViewById(R.id.demo73TxtP);
        txtU = findViewById(R.id.demo73TxtU);
        btnLogin = findViewById(R.id.demo73BtnLogin);
        btnCancel = findViewById(R.id.demo73BtnCancel);
        tvkq = findViewById(R.id.demo73TvKQ);
        chk = findViewById(R.id.demo73Chk);
        List<Object> list = new ArrayList<>();
        list = readPreference();
        if(list.size()>0)
        {
            txtU.setText(list.get(0).toString());
            txtP.setText(list.get(1).toString());
            chk.setChecked(Boolean.parseBoolean(list.get(2).toString()));
        }
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();//dong activity
                System.exit(0);
            }
        });
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String u = txtU.getText().toString();
                String p = txtP.getText().toString();
                boolean status = chk.isChecked();
                if(u.equals("")||p.equals(""))
                {
                    tvkq.setText("Khong duoc de trong");
                    return;
                }
                else if(u.equalsIgnoreCase("admin")&&
                p.equalsIgnoreCase("admin"))
                {
                    tvkq.setText("Dang nhap thanh cong");
                    savePreference(u,p,status);
                    return;
                }
                else
                {
                    tvkq.setText("U hoac P sai");
                    return;
                }

            }
        });
    }
    void savePreference(String u,String p,boolean status)
    {
        SharedPreferences s = getSharedPreferences("HUNG_FILE",MODE_PRIVATE);
        SharedPreferences.Editor editor = s.edit();
        if(status==false)//khong luu
        {
            editor.clear();
        }
        else //luu du lieu
        {
            editor.putString("U",u);
            editor.putString("P",p);
            editor.putBoolean("CHK",status);
        }
        editor.commit();
    }
    List<Object> readPreference()
    {
        List<Object> ls = new ArrayList<>();
        SharedPreferences s = getSharedPreferences("HUNG_FILE",MODE_PRIVATE);
        ls.add(s.getString("U",""));
        ls.add(s.getString("P",""));
        ls.add(s.getBoolean("CHK",false));
        return ls;
    }
}
