package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText txt1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //hien thi thong bao: Toast.makeText(noi hien thi,noi dung,thoi gian).show();
        Toast.makeText(this,"Nguyen Van B, PH0002, Lop CP17301",
                Toast.LENGTH_SHORT).show();

        txt1 = findViewById(R.id.demo1Txt1);//ánh xạ từ XML sang java
        txt1.setText("Vừa thay đổi text cho đối tượng");//thay đổi text cho đối tượng
    }
}
