package com.example.myapplication.demo6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class Demo61Main2Activity extends AppCompatActivity {
    EditText txtMa, txtTen, txtSoLuong;
    Button btnThem, btnSua, btnXoa, btnHienThi;
    ListView lv;
    SanPhamDAO sanPhamDAO;
    ArrayAdapter<String> arrayAdapter;
    List<String> ls = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo61_main2);
        txtMa = findViewById(R.id.demo61Txt1);
        txtTen = findViewById(R.id.demo61Txt2);
        txtSoLuong = findViewById(R.id.demo61Txt3);
        btnThem = findViewById(R.id.demo61btnThem);
        btnSua = findViewById(R.id.demo61btnSua);
        btnXoa = findViewById(R.id.demo61btnXoa);
        btnHienThi = findViewById(R.id.demo61btnHienThi);
        lv = findViewById(R.id.demo61Listview);
        sanPhamDAO = new SanPhamDAO(this);
        ls.clear();
        ls = sanPhamDAO.getAllSanPhamToString();//đọc toàn bộ SP trong bảng sanpham
        arrayAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,ls);
        lv.setAdapter(arrayAdapter);//đưa dữ liệu lên listview
        //Them
        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SanPham s = new SanPham();
                //đọc dữ liệu do người dùng nhập
                s.setMasp(txtMa.getText().toString());
                s.setTensp(txtTen.getText().toString());
                s.setSoluongSP(Integer.parseInt(txtSoLuong.getText().toString()));
                int kq = sanPhamDAO.insertSanPham(s);//thực thi insert
                if(kq==-1)
                {
                    Toast.makeText(getApplicationContext(),"Insert thất bại",Toast.LENGTH_LONG).show();
                }
                if(kq==1)
                {
                    Toast.makeText(getApplicationContext(),"Insert thành công",Toast.LENGTH_LONG).show();
                }
            }
        });
        //Xoa
        btnXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String masp = txtMa.getText().toString();
                int kq = sanPhamDAO.deleteSanPham(masp);
                if(kq==-1)
                {
                    Toast.makeText(getApplicationContext(),"Xóa thất bại",Toast.LENGTH_LONG).show();
                }
                if(kq==1)
                {
                    Toast.makeText(getApplicationContext(),"Xóa thành công",Toast.LENGTH_LONG).show();
                }
            }
        });
        //hiển thị
        btnHienThi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ls.clear();
                ls = sanPhamDAO.getAllSanPhamToString();//đọc toàn bộ SP trong bảng sanpham
                arrayAdapter = new ArrayAdapter<>(Demo61Main2Activity.this,
                        android.R.layout.simple_list_item_1,ls);
                lv.setAdapter(arrayAdapter);//đưa dữ liệu lên listview
            }
        });
        //sua
        btnSua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SanPham s = new SanPham();
                s.setMasp(txtMa.getText().toString());
                s.setTensp(txtTen.getText().toString());
                s.setSoluongSP(Integer.parseInt(txtSoLuong.getText().toString()));
                int kq = sanPhamDAO.updateSanPham(s);
                if(kq==-1)
                {
                    Toast.makeText(getApplicationContext(),"Sủa thất bại",Toast.LENGTH_LONG).show();
                }
                if(kq==1)
                {
                    Toast.makeText(getApplicationContext(),"Sửa thành công",Toast.LENGTH_LONG).show();
                }
            }
        });

    }
}
