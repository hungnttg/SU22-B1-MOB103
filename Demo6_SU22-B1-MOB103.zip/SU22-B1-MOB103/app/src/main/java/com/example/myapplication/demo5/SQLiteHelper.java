package com.example.myapplication.demo5;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class SQLiteHelper extends SQLiteOpenHelper {
    public static final String SQL_PRODUCT="CREATE TABLE PRODUCT(" +
            "id text PRIMARY KEY," +
            "name text," +
            "price real," +
            "image real);";
    //lệnh Tạo bảng sanpham
    public static final String SQL_SANPHAM = " create TABLE sanpham (" +
            "masp text PRIMARY KEY, " +
            "tensp text, " +
            "soluongSP text)";

    //1. Hàm tạo CSDL
    public SQLiteHelper(Context context) {
        super(context, "QLBH.db", null, 1);//thực thi tạo CSDL
    }

    //2. Tạo bảng dữ liệu
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(SQL_PRODUCT);//lệnh tạo bảng Product
        sqLiteDatabase.execSQL(SQL_SANPHAM);//thự thi lệnh tạo bảng sanpham
    }
    //3. Xóa bảng dữ liệu cũ, tạo bảng dữ liệu mới
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS PRODUCT");//xóa bảng cũ, tạo bảng mới
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS sanpham");//xóa bảng cũ, tạo bảng mới
    }
}
