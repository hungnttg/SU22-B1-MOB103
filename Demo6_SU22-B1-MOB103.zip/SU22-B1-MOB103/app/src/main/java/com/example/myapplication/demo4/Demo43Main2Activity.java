package com.example.myapplication.demo4;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class Demo43Main2Activity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo43_main2);
        listView = findViewById(R.id.demo43Listview);
        //1. Tạo nguồn dữ liệu
        List<Contact> arrs = new ArrayList<>();
        arrs.add(new Contact(Color.YELLOW,"An","A0912345678"));
        arrs.add(new Contact(Color.RED,"BInh","B0912345678"));
        arrs.add(new Contact(Color.GRAY,"Cong","C0912345678"));
        arrs.add(new Contact(Color.GREEN,"Dung","D0912345678"));
        arrs.add(new Contact(Color.CYAN,"Em","E0912345678"));
        //2. Goi adapter
        CustomAdapter adapter = new CustomAdapter(this,R.layout.item_row,arrs);
        //3. Dua du lieu len listview
        listView.setAdapter(adapter);
        //4. xu ly su kien cho listview
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Contact c =  arrs.get(i);
                Toast.makeText(getApplicationContext(),c.getName(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}
