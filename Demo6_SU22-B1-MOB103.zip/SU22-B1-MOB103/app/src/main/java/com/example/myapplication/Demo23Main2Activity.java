package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Demo23Main2Activity extends AppCompatActivity {
    TextView tv2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo23_main2);
        tv2 = findViewById(R.id.demo23Tv2);
        //b4: đón xe
        Intent intent = getIntent();
        //dỡ hàng
        String so1 = intent.getExtras().getString("so1");//dỡ gói hàng 1
        String so2 = intent.getExtras().getString("so2");//dỡ gói hàng 2
        //chuyển đổi sang số
        double a = Double.parseDouble(so1);
        double b = Double.parseDouble(so2);
        //tinh tong
        double c = a+b;
        //dán lên màn hình
        tv2.setText(String.valueOf(c));
    }
}
