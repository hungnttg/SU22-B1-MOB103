package com.example.myapplication.demo6;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.myapplication.demo5.SQLiteHelper;

import java.util.ArrayList;
import java.util.List;

public class SanPhamDAO {
    //1. Khai bao cac bien
    private SQLiteDatabase db;
    private SQLiteHelper dbHelper;
    private Context context;
    //2. ham khoi tao
    public SanPhamDAO(Context context)
    {
        this.context = context;
        dbHelper = new SQLiteHelper(context);//thực thi tạo database
        db = dbHelper.getWritableDatabase();//cho phép ghi vào database
    }
    //3. Insert
    public int insertSanPham(SanPham p)
    {
        ContentValues values = new ContentValues();//tạo đối tượng chứa dữ liệu
        //them dữ liệu vào đối tượng chứa
        values.put("masp",p.getMasp());
        values.put("tensp",p.getTensp());
        values.put("soluongSP",p.getSoluongSP());
        //thực thi insert vào bảng dữ liệu
        long kq = db.insert("sanpham",null,values);
        if(kq<=0)//kiểm tra kết quả
        {
            return -1;//insert thất bại
        }
        return 1;//insert thành công
    }
    //4. Update
    public int updateSanPham(SanPham p)
    {
        ContentValues values = new ContentValues();//tạo đối tượng chứa dữ liêu
        //thêm dữ liệu vào đối tượng chứa
        values.put("masp",p.getMasp());
        values.put("tensp",p.getTensp());
        values.put("soluongSP",p.getSoluongSP());
        //thực thi update
        //updat(tenBang,giaTri,DieuKien)
        int kq = db.update("sanpham",values,"masp=?",
                new String[]{p.getMasp()});
        if(kq<=0)//kiểm tra kết quả
        {
            return -1;//update thất bại
        }
        return 1;//update thành công
    }
    //5. delete
    public int deleteSanPham(String masp)
    {
        //thực thi xóa
        int kq = db.delete("sanpham","masp=?",new String[]{masp});
        //kiểm tra kết quả
        if(kq<=0)
        {
            return -1;//xoá thất bại
        }
        return 1;//xóa thành công
    }
    //6. hiển thị tất cả các sản phẩm và chuyển sang chuỗi
    public List<String> getAllSanPhamToString()
    {
        List<String> ls = new ArrayList<>();//Tạo 1 danh sách trống
        //tạo con trỏ để đọc dữ liệu
        Cursor c = db.query("sanpham",null,null,null,
                null,null,null);
        c.moveToFirst();//di chuyển con trỏ về bản ghi đầu tiên
        while (c.isAfterLast()==false)//nếu không phải bản ghi cuối cùng thì tiếp tục đọc
        {
            SanPham s = new SanPham();//tạo mới 1 đối tượng để chứa dữ liệu
            s.setMasp(c.getString(0));//đọc trường masp và đưa vào đối tượng
            s.setTensp(c.getString(1));//đọc trường tensp và đưa vào đối tượng
            s.setSoluongSP(c.getInt(2));//đọc trường soluongSP và đưa vào đối tượng
            //chuyển sang chuỗi
            String chuoi = s.getMasp()+" - "+s.getTensp()+ " - "+ s.getSoluongSP();
            ls.add(chuoi);//đưa sản phẩm vào danh sách
            c.moveToNext();//di chuyển sang bản ghi tiếp theo
        }
        c.close();//đóng kết nối
        return ls;
    }

}
