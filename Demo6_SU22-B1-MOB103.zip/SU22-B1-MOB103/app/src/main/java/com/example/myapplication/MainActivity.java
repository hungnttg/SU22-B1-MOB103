package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    TextView tv;//khai bao
    EditText edt12;
    Button btnDemo3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //anh xa
        tv = findViewById(R.id.textView12);
        edt12 = findViewById(R.id.editText12);
        btnDemo3 = findViewById(R.id.btnDemo3);
        btnDemo3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        //thay doi text
        tv.setText("Text da thay doi");
        edt12.setText("Thay doi lan nua");
        //Khai báo biến
        String masv = "PH0001";
        String tenSV  = "Tran Van B";
        String lop = "CP17306";
        String hienThi = masv+ "; "+tenSV+"; "+lop;
        //Hàm thông báo
        Toast.makeText(this,hienThi,Toast.LENGTH_LONG).show();

    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }
}
