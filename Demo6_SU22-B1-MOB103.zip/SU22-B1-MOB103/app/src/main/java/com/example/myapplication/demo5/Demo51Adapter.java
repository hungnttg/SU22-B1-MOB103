package com.example.myapplication.demo5;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.myapplication.R;

import java.util.List;

public class Demo51Adapter extends ArrayAdapter<Product> {
    private Context context;
    private int resource;
    private List<Product> objects;
    private LayoutInflater inflater;//dịch vụ tạo layout trắng
    public Demo51Adapter(Context context, int resource,List<Product> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.objects = objects;
        //khởi tạo dịch vụ tạo layout trắng
        this.inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    //gọi hàm getView
    //- Tạo layout và gán Textview, Image vào layout
    //- Gán dữ liệu

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //1 Tạo layout và gán Textview, Image vào layout
        Demo51Holder holder;
        if(convertView==null)//khi chưa có layout, ta cần tạo layout mới
        {
            //Tạo layout trắng
            convertView = inflater.inflate(R.layout.item_row_51,null);
            //gán các textview vào layout
            holder  =new Demo51Holder();
            holder.img = convertView.findViewById(R.id.demo51ItemImg1);
            holder.tvName = convertView.findViewById(R.id.demo51ItemTv2);
            holder.tvPrice = convertView.findViewById(R.id.demo51ItemTv3);
            //tạo template để lần sau sử dụng
            convertView.setTag(holder);
        }
        else //khi đã có layout -> gọi ra sử dụng
        {
            holder=(Demo51Holder)convertView.getTag();
        }
        //2 Gán dữ liệu
        Product p = objects.get(position);
        holder.img.setImageResource(p.getImage());
        holder.tvName.setText(p.getName());
        holder.tvPrice.setText(String.valueOf(p.getPrice()));
        return convertView;
    }

    //Tạo lớp ánh xạ với item_row
    public class Demo51Holder{
        ImageView img;
        TextView tvName,tvPrice;
    }
}
